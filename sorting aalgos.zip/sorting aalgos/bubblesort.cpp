#include<iostream>
using namespace std;
void bubbleSort(int* arr, int start, int end)
{
    for(int i=end;i>=1;i--)
    {
        for(int j=0;j<=end-1;j++)
        {
            if(arr[j]>arr[j+1])
            {
                swap(arr[j],arr[j+1]);
            }
        }
    }
}
int main()
{
    int arr[10]={5,1,5,7,2,5,2,3,12,76};
    bubbleSort(arr,0,9);
    for(int i=0;i<10;i++)
    {
        cout<<arr[i]<<" ";
    }
}