#include<iostream>
using namespace std;
void selectionSort(int* arr, int start, int end)
{
    for(int i=0;i<end;i++)
    {
        int minIdx=i;
        for(int j=i+1;j<=end;j++)
        {
            if(arr[j]<arr[minIdx])
            {
                minIdx=j;
            }
        }
        swap(arr[i],arr[minIdx]);
    }
}
int main()
{
    int arr[10]={5,1,5,7,2,5,2,3,12,76};
    selectionSort(arr,0,9);
    for(int i=0;i<10;i++)
    {
        cout<<arr[i]<<" ";
    }
}