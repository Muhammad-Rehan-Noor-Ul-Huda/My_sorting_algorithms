#include<iostream>
using namespace std;
void insertionSort(int* arr, int start, int end)
{
    for(int i=1;i<=end;i++)
    {
        int j=i-1;
        int val=arr[i];
        while(j>=0 && arr[j]>val)
        {
            arr[j+1]=arr[j];
            j--;
        }
        arr[j+1]=val;
    }
}

int main()
{
    int arr[10]={5,1,5,7,2,5,2,3,12,76};
    insertionSort(arr,0,9);
    for(int i=0;i<10;i++)
    {
        cout<<arr[i]<<" ";
    }
}