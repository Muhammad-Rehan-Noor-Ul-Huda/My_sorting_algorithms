#include<iostream>
using namespace std;
void merge(int *arr, int s1,int e1,int s2,int e2) 
{
    int i=s1;
    int j=s2;
    int *temp=new int[e2-s1+1];
    int idx=0;
    while(i<=e1 && j<=e2)
    {
        if(arr[i]<arr[j])
        {
            temp[idx]=arr[i];
            i++;
        }
        else
        {
            temp[idx]=arr[j];
            j++;
        }
        idx++;
    }
    while(i<=e1)
    {
        temp[idx]=arr[i];
        i++;
        idx++;
    }
    while(j<=e2)
    {
        temp[idx]=arr[j];
        j++;
        idx++;
    }
    int tempIdx=s1;
    for(int i=0;i<=e2-s1;i++)
    {
        arr[tempIdx]=temp[i];
        tempIdx++;
    }
    if(temp!=nullptr)
    {
        delete [] temp;
        temp=nullptr;
    }
}
void mergeSort(int* arr, int start, int end)
{
    if(start<end)
    {
        int mid=(start+end)/2;
        mergeSort(arr,start,mid);
        mergeSort(arr,mid+1,end);
        merge(arr,start,mid,mid+1,end);
    }
    
}

int main()
{
    int arr[10]={5,1,5,7,2,5,2,3,12,-1};
    mergeSort(arr,0,9);
    for(int i=0;i<=9;i++)
    {
        cout<<arr[i]<<" ";
    }
}