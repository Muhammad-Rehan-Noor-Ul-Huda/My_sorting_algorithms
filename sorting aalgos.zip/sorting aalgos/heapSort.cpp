#include<iostream>
using namespace std;
void heapify(int i,int n,int* arr)
{
    bool flag=false;
    while(i*2<=n &&flag==false)
    {
        int largest=i;
        int left=i*2;
        int right=left+1;
        if(right<=n && arr[right]>arr[left])
        {
            largest=right;
        }
        else
        {
            largest=left; 
        }
        if(arr[largest]>arr[i])
        {
            swap(arr[largest],arr[i]);
            i=largest;
        }
        else
        {
            flag=true;
        }
    }
}
bool removeMax(int *arr,int n,int &val)
{
    val=arr[1];
    arr[1]=arr[n];
    heapify(1,n-1,arr);
    return true;
}
void heapSort(int* arr,int n)
{
    for(int i=n/2;i>=1;i--)
    {
        heapify(i,n,arr);
    }
    int idx=n;
    for(int i=1;i<=n;i++)
    {
        int val=0;
        removeMax(arr,idx,val);
        arr[idx]=val;
        idx--;
    }
}
int main()
{
    int arr[7]={-99,3,1,2,9,11,99};
    heapSort(arr,6);
    for(int i=1;i<=6;i++)
    {
        cout<<arr[i]<<" ";
    }
    
}