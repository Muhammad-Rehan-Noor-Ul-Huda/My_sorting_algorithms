#include<iostream>
using namespace std;
int pivot(int* arr,int start, int end)
{
    int i=start;
    int j=end;
    int val=arr[start];
    while(j>i)
    {
        while(i<=end && arr[i]<=val)
        {
            i++;
        }
        while(j>=0 && arr[j]>val)
        {
            j--;
        }
        if(j>i)
        {
            swap(arr[j],arr[i]);
        }
    }
    swap(arr[j],arr[start]);

    return j;
}
void quickSort(int* arr, int start, int end)
{
    if(start<end)
    {
        int idx=pivot(arr,start,end);
        quickSort(arr,start,idx-1);
        quickSort(arr,idx+1,end);
    }
}
int main()
{
    int arr[6]={3,1,2,9,11,99};
    cout<<pivot(arr,0,5)<<endl;
    for(int i=0;i<6;i++)
    {
        cout<<arr[i]<<" ";
    }
}